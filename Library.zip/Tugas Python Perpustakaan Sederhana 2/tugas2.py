import csv
import os
import sys
import random
import string


def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')


def kembali():
    print("\n")
    input("Tekan tombol apa saja untuk kembali...")
    clear_screen()


def menu_awal():
    while(True):
        print("***** SELAMAT DATANG DI NF LIBRARY *****")
        print("MENU : ")
        print("[1] Tambah Anggota Baru")
        print("[2] Tambah Buku Baru")
        print("[3] Pinjam Buku")
        print("[4] Kembalikan Buku")
        print("[5] Lihat Data Peminjaman")
        print("[6] Lihat Data Buku")
        print("[7] Lihat Data Anggota")
        print("[8] Keluar")
        try:
            a = int(input("Masukan menu pilihan Anda : "))
            if(a == 1):
                TambahAnggota()
                kembali()
            elif(a == 2):
                TambahBuku()
            elif(a == 3):
                PinjamBuku()
                kembali()
            elif(a == 4):
                KembalikanBuku()
                kembali()
            elif(a == 5):
                TampilkanData()
                kembali()
            elif(a == 6):
                TampilkanDataBuku()
                kembali()
            elif(a == 7):
                TampilkanDataAnggota()
                kembali()
            elif(a == 8):
                print("Terima kasih atas kunjungan Anda...")
                break
            else:
                print("Pilihan Anda salah. Ulangi.")
                kembali()
                continue
        except ValueError:
            print("Pilihan Anda salah. Ulangi.")
            # kembali()
            continue

# done


def TampilkanDataBuku():
    book = open('buku.txt', 'r').read()
    if(book != -1):
        with open("buku.txt", "r+") as f:
            lines = f.read()
            print(lines)
            print()
    else:
        print("Belum ada data buku yang di input")

# done


def TampilkanDataAnggota():
    members = open('anggota.txt', 'r').read()
    if(members != -1):
        with open("anggota.txt", "r+") as f:
            lines = f.read()
            print(lines)
            print()
    else:
        print("Belum ada data anggota yang di input")

# done


def TampilkanData():
    peminjaman = open('peminjaman.txt', 'r').read()
    if(peminjaman != -1):
        print("*** DAFTAR PEMINJAMAN BUKU ***")
        with open("peminjaman.txt", "r") as f:
            lines = f.readlines()
            lines = [x.strip('\n') for x in lines]
            for i in range(len(lines)):
                temp = lines[i].split(',')
                for a in lines[i].split(','):
                    if (a != ''):
                        with open("buku.txt", "r") as c:
                            lines1 = c.readlines()
                            lines1 = [x.strip('\n') for x in lines1]
                            for i in range(len(lines1)):
                                for d in lines1[i].split(','):
                                    if(d == a):
                                        # buku
                                        vvd = lines1[i].split(',')
                                        print('\n' + "Judul: " + vvd[1])
                                        print("Penulis: " + vvd[2])

                                        # peminjam
                                        print("Daftar Peminjam:")
                                        kl = 0
                                        dc = 0
                                        for dn in temp:
                                            if(kl != 0):
                                                with open("anggota.txt", "r") as v:
                                                    lines3 = v.readlines()
                                                    lines3 = [
                                                        x.strip('\n') for x in lines3]
                                                    for dd in range(len(lines3)):
                                                        for ccc in lines3[dd].split(','):
                                                            if(ccc == dn):
                                                                ff = lines3[dd].split(
                                                                    ',')
                                                                if (str(ff[2]) == '1'):
                                                                    print(
                                                                        str(dc+1) + ". " + str(ff[1]) + "(*)")
                                                                else:
                                                                    print(
                                                                        str(dc+1) + ". " + str(ff[1]))
                                                                dc += 1
                                            kl += 1
    else:
        print("Tidak ada buku yang sedang dipinjam.")

# done


def TambahAnggota():
    print("*** PENDAFTARAN ANGGOTA BARU ***")
    with open("anggota.txt", "a+") as f:
        kode = "LIB" + ''.join(random.choice(string.digits) for _ in range(3))
        nama = input("Masukan nama: ")
        anggota = ''
        while(True):
            anggota = input("Apakah merupakan karyawan NF Group? (Y/T): ")
            if (anggota == 'y' or anggota == 'Y'):
                anggota = '1'
                break
            elif (anggota == 't' or anggota == 'T'):
                anggota = '2'
                break
            else:
                continue
        f.write('\n' + kode + "," + nama + "," + str(anggota))
        print("Pendaftaran anggota dengan kode " +
            kode+" atas nama "+nama+" berhasil.")

# done


def TambahBuku():
    print("*** PENAMBAHAN BUKU BARU ***")
    with open("buku.txt", "a+") as f:
        judul = input("Judul: ")
        penulis = input("Penulis: ")
        stok = input("Stok: ")
        kode = penulis[:3].upper() + ''.join(random.choice(string.digits)
            for _ in range(3))
        f.write('\n' + kode + "," + judul + "," + penulis + "," + str(stok))
        print("Penambahan buku baru dengan kode " +
            kode+" dan judul "+judul+" berhasil.")

# done


def PinjamBuku():
    # variable
    global kode1
    global judul_buku
    global penulis
    global stok
    kode1 = []
    judul_buku = []
    penulis = []
    stok = []

    print("*** PEMINJAMAN BUKU ***")
    codebook = input("Kode buku: ")
    cdbk = open('buku.txt', 'r').read().find(codebook)
    if (cdbk != -1):
        codemember = input("Kode anggota: ")
        cdmember = open('anggota.txt', 'r').read().find(codemember)
        if (cdmember != -1):
            with open("buku.txt", "r") as f:
                lines = f.readlines()
                lines = [x.strip('\n') for x in lines]
            for i in range(len(lines)):
                for a in lines[i].split(','):
                    if(a == codebook):
                        ind = 0
                        for a in lines[i].split(','):
                            if(ind == 0):
                                kode1.append(a)
                            if(ind == 1):
                                judul_buku.append(a)
                            if(ind == 2):
                                penulis.append(a)
                            if(ind == 3):
                                stok.append(a)
                                break
                            ind += 1

            if(str(stok[0]) == '0'):
                print("Stok buku kosong. Peminjaman gagal.")
            else:
                bk = open('peminjaman.txt', 'r').read().find(codebook)
                if(bk != -1):
                    with open("peminjaman.txt", "r+") as a:
                        # variable peminjaman
                        global codebook1
                        global codemember1
                        codebook1 = []
                        codemember1 = []

                        lines1 = a.readlines()
                        lines1 = [x.strip('\n') for x in lines1]
                        for i in range(len(lines1)):
                            for a in lines1[i].split(','):
                                if(a == codebook):
                                    ind = 0
                                    for a in lines1[i].split(','):
                                        if(ind == 0):
                                            codebook1.append(a)
                                        else:
                                            codemember1.append(a)
                                        ind += 1

                        bef = str(codebook1[0]) + "," + ','.join(codemember1)
                        aft = bef + "," + str(codemember)

                        # open file
                        with open('peminjaman.txt', 'r') as files:
                            pmjm = files.read()

                        # Replace the target string
                        pmjm = pmjm.replace(bef, aft)

                        # Write the file out again
                        with open('peminjaman.txt', 'w') as file:
                            file.write(pmjm)

                        # pengurangan stok
                        before = str(kode1[0]) + "," + str(judul_buku[0]) + \
                            "," + str(penulis[0]) + "," + str(stok[0])
                        stok[0] = int(stok[0])-1
                        after = str(kode1[0]) + "," + str(judul_buku[0]) + \
                            "," + str(penulis[0]) + "," + str(stok[0])

                        # open file
                        with open('buku.txt', 'r') as file:
                            filedata = file.read()

                        # Replace the target string
                        filedata = filedata.replace(before, after)

                        # Write the file out again
                        with open('buku.txt', 'w') as file:
                            file.write(filedata)

                        # print validasi
                        print("Peminjaman buku "+codebook +
                            " oleh "+codemember+" berhasil.")
                else:
                    with open("peminjaman.txt", "a+") as f:
                        f.write('\n' + codebook + "," + codemember)

                        # pengurangan stok
                        before = str(kode1[0]) + "," + str(judul_buku[0]) + \
                            "," + str(penulis[0]) + "," + str(stok[0])
                        stok[0] = int(stok[0])-1
                        after = str(kode1[0]) + "," + str(judul_buku[0]) + \
                            "," + str(penulis[0]) + "," + str(stok[0])

                        # open file
                        with open('buku.txt', 'r') as file:
                            filedata = file.read()

                        # Replace the target string
                        filedata = filedata.replace(before, after)

                        # Write the file out again
                        with open('buku.txt', 'w') as file:
                            file.write(filedata)

                        # notifikasi
                        print("Peminjaman buku "+codebook +
                            " oleh "+codemember+" berhasil.")
        else:
            print("Kode anggota tidak terdaftar. Peminjaman gagal.")
    else:
        print("Kode buku tidak ditemukan. Peminjaman gagal.")

# done


def KembalikanBuku():
    # variable
    global kode1
    global judul_buku
    global penulis
    global stok
    kode1 = []
    judul_buku = []
    penulis = []
    stok = []

    print("*** PENGEMBALIAN BUKU ***")
    codebook = input("Kode buku: ")
    cdbk = open('buku.txt', 'r').read().find(codebook)
    if (cdbk != -1):
        codemember = input("Kode anggota: ")
        cdmember = open('anggota.txt', 'r').read().find(codemember)
        if (cdmember != -1):
            bk = open('peminjaman.txt', 'r').read().find(codebook)
            if (bk != -1):
                with open("peminjaman.txt", "r+") as a:
                    # variable peminjaman
                    global codebook1
                    global codemember1
                    codebook1 = []
                    codemember1 = []

                    lines1 = a.readlines()
                    lines1 = [x.strip('\n') for x in lines1]
                    for i in range(len(lines1)):
                        for a in lines1[i].split(','):
                            if(a == codebook):
                                ind = 0
                                for a in lines1[i].split(','):
                                    if(ind == 0):
                                        codebook1.append(a)
                                    else:
                                        codemember1.append(a)
                                    ind += 1

                    for df in codemember1:
                        if(len(codemember1) == 1):
                            if (str(df) == str(codemember)):
                                bef = str(codebook1[0]) + \
                                    "," + ','.join(codemember1)
                                aft = ""

                                # open file
                                with open('peminjaman.txt', 'r') as files:
                                    pmjm = files.read()

                                # Replace the target string
                                pmjm = pmjm.replace(bef, aft)

                                # Write the file out again
                                with open('peminjaman.txt', 'w') as file:
                                    file.write(pmjm)

                                # pengurangan stok
                                with open("buku.txt", "r") as f:
                                    lines = f.readlines()
                                    lines = [x.strip('\n') for x in lines]

                                    for i in range(len(lines)):
                                        for a in lines[i].split(','):
                                            if(a == codebook):
                                                ind = 0
                                                for a in lines[i].split(','):
                                                    if(ind == 0):
                                                        kode1.append(a)
                                                    if(ind == 1):
                                                        judul_buku.append(a)
                                                    if(ind == 2):
                                                        penulis.append(a)
                                                    if(ind == 3):
                                                        stok.append(a)
                                                        break
                                                    ind += 1

                                before = str(
                                    kode1[0]) + "," + str(judul_buku[0]) + "," + str(penulis[0]) + "," + str(stok[0])
                                stok[0] = int(stok[0])+1
                                after = str(
                                    kode1[0]) + "," + str(judul_buku[0]) + "," + str(penulis[0]) + "," + str(stok[0])

                                # open file
                                with open('buku.txt', 'r') as file:
                                    filedata = file.read()

                                # Replace the target string
                                filedata = filedata.replace(before, after)

                                # Write the file out again
                                with open('buku.txt', 'w') as file:
                                    file.write(filedata)

                                # validasi denda
                                hari = int(
                                    input("Keterlambatan pengembalian (dalam hari, 0 jika tidak terlambat) : "))

                                # variable anggota
                                global kode45
                                global nama45
                                global stats45
                                kode45 = []
                                nama45 = []
                                stats45 = []

                                with open("anggota.txt", "r") as f:
                                    lines = f.readlines()
                                    lines = [x.strip('\n') for x in lines]
                                    for i in range(len(lines)):
                                        for a in lines[i].split(','):
                                            if(a == codemember):
                                                ind = 0
                                                for a in lines[i].split(','):
                                                    if(ind == 0):
                                                        kode45.append(a)
                                                    if(ind == 1):
                                                        nama45.append(a)
                                                    if(ind == 2):
                                                        stats45.append(a)
                                                    ind += 1

                                    if (hari != 0):
                                        if(str(stats45[0]) == '1'):
                                            denda = 1000*hari
                                            print("Total denda = "+str(denda))
                                            print(
                                                "Silakan membayar denda keterlambatan di kasir.")
                                        elif(str(stats45[0]) == '2'):
                                            denda = 2500*hari
                                            print("Total denda = "+str(denda))
                                            print(
                                                "Silakan membayar denda keterlambatan di kasir.")

                                # print validasi
                                print("Pengembalian buku "+codebook +
                                    " oleh "+codemember+" berhasil.")

                            else:
                                print("kode anggota "+codemember +
                                    " sedang tidak meminjam kode buku " + codebook)
                            break
                        else:
                            if (str(df) == str(codemember)):
                                bef = str(codebook1[0]) + \
                                    "," + ','.join(codemember1)
                                aft = bef.replace(',' + codemember, '')

                                # open file
                                with open('peminjaman.txt', 'r') as files:
                                    pmjm = files.read()

                                # Replace the target string
                                pmjm = pmjm.replace(bef, aft)

                                # Write the file out again
                                with open('peminjaman.txt', 'w') as file:
                                    file.write(pmjm)

                                # pengurangan stok
                                with open("buku.txt", "r") as f:
                                    lines = f.readlines()
                                    lines = [x.strip('\n') for x in lines]

                                    for i in range(len(lines)):
                                        for a in lines[i].split(','):
                                            if(a == codebook):
                                                ind = 0
                                                for a in lines[i].split(','):
                                                    if(ind == 0):
                                                        kode1.append(a)
                                                    if(ind == 1):
                                                        judul_buku.append(a)
                                                    if(ind == 2):
                                                        penulis.append(a)
                                                    if(ind == 3):
                                                        stok.append(a)
                                                        break
                                                    ind += 1

                                before = str(
                                    kode1[0]) + "," + str(judul_buku[0]) + "," + str(penulis[0]) + "," + str(stok[0])
                                stok[0] = int(stok[0])+1
                                after = str(
                                    kode1[0]) + "," + str(judul_buku[0]) + "," + str(penulis[0]) + "," + str(stok[0])

                                # open file
                                with open('buku.txt', 'r') as file:
                                    filedata = file.read()

                                # Replace the target string
                                filedata = filedata.replace(before, after)

                                # Write the file out again
                                with open('buku.txt', 'w') as file:
                                    file.write(filedata)

                                # validasi denda
                                hari = int(
                                    input("Keterlambatan pengembalian (dalam hari, 0 jika tidak terlambat) : "))

                                # variable anggota
                                global kode
                                global nama
                                global stats
                                kode = []
                                nama = []
                                stats = []

                                with open("anggota.txt", "r") as f:
                                    lines = f.readlines()
                                    lines = [x.strip('\n') for x in lines]
                                    for i in range(len(lines)):
                                        for a in lines[i].split(','):
                                            if(a == codemember):
                                                ind = 0
                                                for a in lines[i].split(','):
                                                    if(ind == 0):
                                                        kode.append(a)
                                                    if(ind == 1):
                                                        nama.append(a)
                                                    if(ind == 2):
                                                        stats.append(a)
                                                    ind += 1

                                    if (hari != 0):
                                        if(str(stats[0]) == '1'):
                                            denda = 1000*hari
                                            print("Total denda = "+str(denda))
                                            print(
                                                "Silakan membayar denda keterlambatan di kasir.")
                                        elif(str(stats[0]) == '2'):
                                            denda = 2500*hari
                                            print("Total denda = "+str(denda))
                                            print(
                                                "Silakan membayar denda keterlambatan di kasir.")

                                # print validasi
                                print("Pengembalian buku "+codebook +
                                    " oleh "+codemember+" berhasil.")

                            else:
                                print("kode anggota "+codemember +
                                    " sedang tidak meminjam kode buku " + codebook)
                            break
            else:
                print("Buku sedang tidak dalam peminjamanan")
        else:
            print(
                "Kode anggota tidak terdaftar sebagai peminjam buku tersebut. Pengembalian buku gagal.")
    else:
        print("Kode buku salah. Pengembalian buku gagal.")

menu_awal()